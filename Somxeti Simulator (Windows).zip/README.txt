Somxeti Simulator: Made By Monke

Protecc Hayastan from infidels using your advanced jet technology and blast "God Syria and Bashar" at full volume while you're at it.

//Changelog

-v0.9 base game done

-v0.91 now with adjustable volume and vfx!
	-v0.911 fixed volume bug

-v0.922 now with a proper settings screen and improved overall (more gameplay to come...)
 __  __  ___  _  _ _  _____ 
|  \/  |/ _ \| \| | |/ / __|
| |\/| | (_) | .` | ' <| _| 
|_|  |_|\___/|_|\_|_|\_\___|
                            
(For legal reasons, this game is a joke, i dont mean any harm towards Armenia nor Armenian people)